import type { NavItem } from "@/types/manualTypes"

export const navItems: NavItem[] = [
  { id: "overview", title: "Содержание", icon: "📋" },
  { id: "lectures", title: "Лекции", icon: "📚" },
  { id: "training", title: "Тренировки", icon: "🏃" },
  { id: "events", title: "Мероприятия", icon: "🎯" },
  { id: "rp-task", title: "РП задания", icon: "⁉️" },
  { id: "exam-section", title: "Правила проведения экзаменов", icon: "📝" },
  { id: "ammunition-supplies", title: "Правила поставки боеприпасов", icon: "🚚" },
  { id: "interview-conscript", title: "Собеседование (Срочная)", icon: "👤" },
  { id: "interview-contract", title: "Собеседование (Контракт)", icon: "👥" },
  { id: "ministry-of-defense", title: "Доклады и Тен-коды", icon: "🎤" },
  { id: "goss-wave", title: "Гос Волна", icon: "📻" },
  { id: "announcements", title: "Шаблоны для Доски Объявлений", icon: "📢" },
  { id: "forum-responses", title: "Работа по форуму", icon: "💬" },
  { id: "report-generator", title: "Генератор отчетов", icon: "📝" },
  { id: "user-management", title: "Управление пользователями", icon: "👥" },
]
